using System;
using ZooManagement.Domain;
using ZooManagement.Services;
using ZooManagement.UI;

namespace ZooManagement.Business
{
    public class ZooManager
    {
        private readonly IZoo _zoo;
        private readonly IVetClinic _vetClinic;

        public ZooManager(IZoo zoo, IVetClinic vetClinic)
        {
            _zoo = zoo;
            _vetClinic = vetClinic;
        }

        public void AddAnimal()
        {
            Console.WriteLine("Выберите тип животного для добавления:");
            Console.WriteLine("1. Обезьяна");
            Console.WriteLine("2. Кролик");
            Console.WriteLine("3. Тигр");
            Console.WriteLine("4. Волк");
            string typeChoice = Console.ReadLine();

            int number = UserInput.ReadInt("Введите инвентаризационный номер животного: ");
            if (_zoo.ContainsAnimalNumber(number))
            {
                Console.WriteLine("Ошибка: животное с таким номером уже существует.");
                return;
            }

            int food = UserInput.ReadInt("Введите количество потребляемой еды (кг/день): ");
            Animal animal = typeChoice switch
            {
                "1" => new Monkey(number, food, "Обезьяна", UserInput.ReadInt("Введите уровень доброты (0-10): ")),
                "2" => new Rabbit(number, food, "Кролик", UserInput.ReadInt("Введите уровень доброты (0-10): ")),
                "3" => new Tiger(number, food, "Тигр"),
                "4" => new Wolf(number, food, "Волк"),
                _ => null
            };

            if (animal == null)
            {
                Console.WriteLine("Неверный выбор типа животного.");
                return;
            }

            if (_vetClinic.CheckAnimalHealth(animal))
            {
                _zoo.AddAnimal(animal);
                Console.WriteLine("Животное успешно добавлено в зоопарк.");
            }
            else
            {
                Console.WriteLine("Животное не прошло ветеринарный осмотр.");
            }
        }

        public void AddAnimalToContactZoo()
        {
            int number = UserInput.ReadInt("Введите инвентаризационный номер животного для контактного зоопарка: ");
            Animal animal = _zoo.GetAnimalByNumber(number);
            if (animal == null)
            {
                Console.WriteLine("Животное с таким номером не найдено.");
                return;
            }
            _zoo.AddToContactZoo(animal);
        }

        public void AddInventoryItem()
        {
            string typeChoice = "";
            while (true)
            {
                Console.WriteLine("Выберите тип инвентарного объекта:");
                Console.WriteLine("1. Стол");
                Console.WriteLine("2. Компьютер");
                typeChoice = Console.ReadLine();
                if (typeChoice == "1" || typeChoice == "2")
                    break;
                Console.WriteLine("Неверный выбор типа объекта. Попробуйте снова.");
            }

            int number = UserInput.ReadInt("Введите инвентаризационный номер объекта: ");
            if (_zoo.ContainsInventoryNumber(number))
            {
                Console.WriteLine("Ошибка: объект с таким номером уже существует.");
                return;
            }

            IInventory item = typeChoice switch
            {
                "1" => new Table(number),
                "2" => new Computer(number),
                _ => null
            };

            if (item == null)
            {
                Console.WriteLine("Неверный выбор типа объекта.");
                return;
            }

            _zoo.AddThing(item);
            Console.WriteLine($"Объект \"{item.Name}\" с номером {item.Number} добавлен в инвентаризацию.");
        }
    }
}
