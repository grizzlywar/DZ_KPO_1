namespace ZooManagement.Services
{
    using ZooManagement.Domain;

    public interface IVetClinic
    {
        bool CheckAnimalHealth(Animal animal);
    }
}