using System;
using ZooManagement.Domain;

namespace ZooManagement.Services
{
    public class VetClinic : IVetClinic
    {
        public bool CheckAnimalHealth(Animal animal)
        {
            Console.WriteLine($"Проводится осмотр животного {animal.Name} (Номер: {animal.Number}).");
            Console.Write("Введите Y, если животное здорово, иначе N: ");
            var input = Console.ReadLine();
            return input?.Trim().ToLower() == "y";
        }
    }
}