using System;
using System.Collections.Generic;
using System.Linq;
using ZooManagement.Domain;

namespace ZooManagement.Services
{
    public class Zoo : IZoo
    {
        private readonly List<Animal> _animals = new();
        private readonly List<IInventory> _inventory = new();
        private readonly List<Animal> _contactZooAnimals = new();

        public void AddAnimal(Animal animal) => _animals.Add(animal);

        public void AddThing(IInventory thing) => _inventory.Add(thing);

        public int TotalFoodConsumption() => _animals.Sum(a => a.Food);

        public IEnumerable<Animal> GetContactZooAnimals() => _contactZooAnimals;

        public IEnumerable<Animal> GetAllAnimals() => _animals;

        public IEnumerable<IInventory> GetAllInventory() => _inventory;

        public void PrintInventory()
        {
            if (!_inventory.Any())
            {
                Console.WriteLine("Инвентаризация пуста.");
                return;
            }
            Console.WriteLine("Инвентаризация объектов зоопарка:");
            foreach (var item in _inventory)
                Console.WriteLine(item is Thing thing ? thing.GetDetails() : $"Название: {item.Name}, Номер: {item.Number}");
        }

        public void PrintAnimalsReport()
        {
            if (!_animals.Any())
            {
                Console.WriteLine("Животных нет.");
                return;
            }
            Console.WriteLine("Животные зоопарка:");
            foreach (var animal in _animals)
                Console.WriteLine(animal.GetDetails());
        }

        public void AddToContactZoo(Animal animal)
        {
            if (!animal.IsSuitableForContactZoo())
            {
                Console.WriteLine($"Животное {animal.Name} (Номер: {animal.Number}) не подходит для контактного зоопарка.");
                return;
            }
            if (_contactZooAnimals.Exists(a => a.Number == animal.Number))
            {
                Console.WriteLine($"Животное {animal.Name} (Номер: {animal.Number}) уже в контактном зоопарке.");
                return;
            }
            _contactZooAnimals.Add(animal);
            Console.WriteLine($"Животное {animal.Name} (Номер: {animal.Number}) добавлено в контактный зоопарк.");
        }

        public bool ContainsAnimalNumber(int number) => _animals.Exists(a => a.Number == number);

        public Animal GetAnimalByNumber(int number) => _animals.Find(a => a.Number == number);

        public bool ContainsInventoryNumber(int number) => _inventory.Exists(i => i.Number == number);
    }
}
