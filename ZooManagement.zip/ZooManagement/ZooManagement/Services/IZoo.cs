using System.Collections.Generic;
using ZooManagement.Domain;

namespace ZooManagement.Services
{
    public interface IZoo
    {
        void AddAnimal(Animal animal);
        void AddThing(IInventory thing);
        int TotalFoodConsumption();
        IEnumerable<Animal> GetContactZooAnimals();
        IEnumerable<Animal> GetAllAnimals();
        IEnumerable<IInventory> GetAllInventory();
        void PrintInventory();
        void PrintAnimalsReport();
        void AddToContactZoo(Animal animal);
        bool ContainsAnimalNumber(int number);
        Animal GetAnimalByNumber(int number);
        bool ContainsInventoryNumber(int number);
    }
}