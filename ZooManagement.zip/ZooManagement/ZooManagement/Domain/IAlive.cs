namespace ZooManagement.Domain
{
    public interface IAlive
    {
        int Food { get; set; }
    }
}