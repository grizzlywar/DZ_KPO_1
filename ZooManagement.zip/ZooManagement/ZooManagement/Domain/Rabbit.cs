namespace ZooManagement.Domain
{
    public class Rabbit : Herbo
    {
        public Rabbit(int number, int food, string name, int kindness)
            : base(number, food, name, kindness)
        { }
    }
}