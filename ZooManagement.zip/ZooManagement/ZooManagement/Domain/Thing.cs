namespace ZooManagement.Domain
{
    public abstract class Thing : IInventory
    {
        public int Number { get; set; }
        public string Name { get; protected set; }

        protected Thing(int number, string name)
        {
            Number = number;
            Name = name;
        }

        public virtual string GetDetails() => $"Название: {Name}, Номер: {Number}";
    }
}