namespace ZooManagement.Domain
{
    public interface IInventory
    {
        int Number { get; set; }
        string Name { get; }
    }
}