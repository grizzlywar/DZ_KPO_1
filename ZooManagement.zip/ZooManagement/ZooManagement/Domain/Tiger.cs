namespace ZooManagement.Domain
{
    public class Tiger : Predator
    {
        public Tiger(int number, int food, string name)
            : base(number, food, name)
        { }
    }
}