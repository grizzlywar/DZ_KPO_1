namespace ZooManagement.Domain
{
    public class Computer : Thing
    {
        public Computer(int number, string name = "Компьютер")
            : base(number, name)
        { }
    }
}