namespace ZooManagement.Domain
{
    public class Wolf : Predator
    {
        public Wolf(int number, int food, string name)
            : base(number, food, name)
        { }
    }
}