namespace ZooManagement.Domain
{
    public class Monkey : Herbo
    {
        public Monkey(int number, int food, string name, int kindness)
            : base(number, food, name, kindness)
        { }
    }
}