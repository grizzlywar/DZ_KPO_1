using ZooManagement.Domain;

namespace ZooManagement.Domain
{
    public abstract class Animal : IAlive, IInventory
    {
        public int Food { get; set; }
        public int Number { get; set; }
        public string Name { get; protected set; }

        protected Animal(int number, int food, string name)
        {
            Number = number;
            Food = food;
            Name = name;
        }
        public abstract bool IsSuitableForContactZoo();
        public virtual string GetDetails()
        {
            string type = this is Herbo ? "Травоядное" : "Хищное";
            string contact = IsSuitableForContactZoo() ? "Подходит для контактного зоопарка" : "Не подходит для контактного зоопарка";
            string extra = "";
            if (this is Herbo herbAnimal)
            {
                extra = $", Доброта: {herbAnimal.Kindness}";
            }
            return $"Название: {Name}, Номер: {Number}, Еда: {Food} кг/день, Тип: {type}{extra}, {contact}";
        }
    }
}