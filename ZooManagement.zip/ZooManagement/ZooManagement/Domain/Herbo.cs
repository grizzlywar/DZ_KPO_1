namespace ZooManagement.Domain
{
    public abstract class Herbo : Animal
    {
        public int Kindness { get; set; }

        protected Herbo(int number, int food, string name, int kindness)
            : base(number, food, name)
        {
            Kindness = kindness;
        }

        public override bool IsSuitableForContactZoo() => Kindness > 5;
    }
}