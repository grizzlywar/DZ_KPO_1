namespace ZooManagement.Domain
{
    public abstract class Predator : Animal
    {
        protected Predator(int number, int food, string name)
            : base(number, food, name)
        { }

        public override bool IsSuitableForContactZoo() => false;
    }
}