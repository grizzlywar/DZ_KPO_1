namespace ZooManagement.Domain
{
    public class Table : Thing
    {
        public Table(int number, string name = "Стол")
            : base(number, name)
        { }
    }
}