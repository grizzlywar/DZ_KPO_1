﻿using Microsoft.Extensions.DependencyInjection;
using ZooManagement.Services;
using ZooManagement.Business;
using ZooManagement.UI;

namespace ZooManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            var provider = services.BuildServiceProvider();

            var zoo = provider.GetService<IZoo>();
            var vetClinic = provider.GetService<IVetClinic>();
            var zooManager = new ZooManager(zoo, vetClinic);
            var ui = new UserInterface(zooManager, zoo);
            ui.Run();
        }

        private static void ConfigureServices(ServiceCollection services)
        {
            services.AddSingleton<IZoo, Zoo>();
            services.AddSingleton<IVetClinic, VetClinic>();
        }
    }
}