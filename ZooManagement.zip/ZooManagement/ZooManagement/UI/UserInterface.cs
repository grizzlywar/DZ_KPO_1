using System;
using System.Linq;
using ZooManagement.Services;
using ZooManagement.Business;

namespace ZooManagement.UI
{
    public class UserInterface
    {
        private readonly ZooManager _manager;
        private readonly IZoo _zoo;

        public UserInterface(ZooManager manager, IZoo zoo)
        {
            _manager = manager;
            _zoo = zoo;
        }

        public void Run()
        {
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\nВыберите действие:");
                Console.WriteLine("1. Добавить новое животное");
                Console.WriteLine("2. Добавить животное в контактный зоопарк");
                Console.WriteLine("3. Вывести отчёт о животных");
                Console.WriteLine("4. Вывести статистику зоопарка");
                Console.WriteLine("5. Вывести список животных контактного зоопарка");
                Console.WriteLine("6. Вывести инвентаризацию");
                Console.WriteLine("7. Добавить инвентарный объект");
                Console.WriteLine("0. Выход");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        _manager.AddAnimal();
                        break;
                    case "2":
                        if (!_zoo.GetAllAnimals().Any())
                            Console.WriteLine("В зоопарке нет животных.");
                        else
                            _manager.AddAnimalToContactZoo();
                        break;
                    case "3":
                        if (!_zoo.GetAllAnimals().Any())
                            Console.WriteLine("В зоопарке нет животных.");
                        else
                            _zoo.PrintAnimalsReport();
                        break;
                    case "4":
                        if (!_zoo.GetAllAnimals().Any())
                        {
                            Console.WriteLine("В зоопарке нет животных.");
                        }
                        else
                        {
                            var allAnimals = _zoo.GetAllAnimals().ToList();
                            int totalAnimals = allAnimals.Count;
                            int contactAnimals = _zoo.GetContactZooAnimals().Count();
                            int totalFood = _zoo.TotalFoodConsumption();
                            int predators = allAnimals.Count(a => a is ZooManagement.Domain.Predator);
                            int herbivores = allAnimals.Count(a => a is ZooManagement.Domain.Herbo);

                            Console.WriteLine("Статистика зоопарка:");
                            Console.WriteLine($"Общее количество животных: {totalAnimals}");
                            Console.WriteLine($"Количество животных в контактном зоопарке: {contactAnimals}");
                            Console.WriteLine($"Общий расход еды: {totalFood} кг/день");
                            Console.WriteLine($"Количество хищных: {predators}");
                            Console.WriteLine($"Количество травоядных: {herbivores}");
                        }
                        break;
                    case "5":
                        if (!_zoo.GetAllAnimals().Any())
                            Console.WriteLine("В зоопарке нет животных.");
                        else
                        {
                            var contactAnimals = _zoo.GetContactZooAnimals();
                            if (!contactAnimals.Any())
                                Console.WriteLine("В контактном зоопарке нет животных.");
                            else
                            {
                                Console.WriteLine("Животные контактного зоопарка:");
                                foreach (var animal in contactAnimals)
                                    Console.WriteLine(animal.GetDetails());
                            }
                        }
                        break;
                    case "6":
                        if (!_zoo.GetAllAnimals().Any())
                            Console.WriteLine("В зоопарке нет животных.");
                        else
                            _zoo.PrintInventory();
                        break;
                    case "7":
                        _manager.AddInventoryItem();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Неверный ввод, попробуйте снова.");
                        break;
                }
            }
        }
    }
}
