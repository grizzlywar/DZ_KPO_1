using System;

namespace ZooManagement.UI
{
    public static class UserInput
    {
        public static int ReadInt(string prompt)
        {
            int result;
            while (true)
            {
                Console.Write(prompt);
                var input = Console.ReadLine();
                if (int.TryParse(input, out result))
                    return result;
                Console.WriteLine("Ошибка: введите корректное число.");
            }
        }
    }
}
