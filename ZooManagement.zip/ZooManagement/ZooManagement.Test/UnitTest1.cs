using System;
using System.IO;
using System.Linq;
using Xunit;
using ZooManagement.Domain;
using ZooManagement.Services;
using ZooManagement.Business;
using ZooManagement.UI;

namespace ZooManagement.Test
{
    public class UnitTest1
    {
        #region VetClinic and RandomVetClinic tests

        [Fact]
        public void VetClinic_CheckAnimalHealth_ReturnsTrue_WhenInputY()
        {
            var tiger = new Tiger(5, 6, "Stripes");
            var vetClinic = new VetClinic();
            using (var sr = new StringReader("y\n"))
            {
                var originalIn = Console.In;
                try
                {
                    Console.SetIn(sr);
                    bool result = vetClinic.CheckAnimalHealth(tiger);
                    Assert.True(result, "При вводе 'y' метод должен вернуть true.");
                }
                finally
                {
                    Console.SetIn(originalIn);
                }
            }
        }

        [Fact]
        public void VetClinic_CheckAnimalHealth_ReturnsFalse_WhenInputN()
        {
            var wolf = new Wolf(11, 4, "Grey");
            var vetClinic = new VetClinic();
            using (var sr = new StringReader("n\n"))
            {
                var originalIn = Console.In;
                try
                {
                    Console.SetIn(sr);
                    bool result = vetClinic.CheckAnimalHealth(wolf);
                    Assert.False(result, "При вводе 'n' метод должен вернуть false.");
                }
                finally
                {
                    Console.SetIn(originalIn);
                }
            }
        }
        public class RandomVetClinic : IVetClinic
        {
            private readonly Random _random;
            public RandomVetClinic(int seed) => _random = new Random(seed);

            public bool CheckAnimalHealth(Animal animal)
            {
                // 50/50 шанс
                return _random.Next(2) == 0;
            }
        }

        [Fact]
        public void RandomVetClinic_CheckAnimalHealth_ReturnsDeterministicValue()
        {
            var tiger = new Tiger(50, 10, "RandomTiger");
            IVetClinic randomClinic = new RandomVetClinic(42);
            bool result = randomClinic.CheckAnimalHealth(tiger);
            Assert.False(result, "При сиде 42 ожидается детерминированный результат false.");
        }

        #endregion

        #region Domain Animal tests

        [Fact]
        public void Rabbit_WithHighKindness_IsSuitableForContactZoo()
        {
            var rabbit = new Rabbit(1, 2, "Bunny", 7);
            Assert.True(rabbit.IsSuitableForContactZoo());
        }

        [Fact]
        public void Rabbit_WithLowKindness_IsNotSuitableForContactZoo()
        {
            var rabbit = new Rabbit(2, 2, "BunnyLow", 4);
            Assert.False(rabbit.IsSuitableForContactZoo());
        }

        [Fact]
        public void Wolf_IsNotSuitableForContactZoo()
        {
            var wolf = new Wolf(3, 5, "Wolfie");
            Assert.False(wolf.IsSuitableForContactZoo());
        }

        [Fact]
        public void Animal_GetDetails_ReturnsCorrectFormat_ForHerbivore()
        {
            var rabbit = new Rabbit(4, 3, "Fluffy", 8);
            string details = rabbit.GetDetails();
            Assert.Contains("Fluffy", details);
            Assert.Contains("Номер: 4", details);
            Assert.Contains("Еда: 3 кг/день", details);
            Assert.Contains("Травоядное", details);
            Assert.Contains("Доброта: 8", details);
            Assert.Contains("Подходит", details);
        }

        [Fact]
        public void Animal_GetDetails_ReturnsCorrectFormat_ForPredator()
        {
            var tiger = new Tiger(5, 6, "Stripes");
            string details = tiger.GetDetails();
            Assert.Contains("Stripes", details);
            Assert.Contains("Хищное", details);
            Assert.Contains("Не подходит", details);
        }

        #endregion

        #region Zoo tests

        [Fact]
        public void Zoo_AddAnimal_IncreasesCount()
        {
            IZoo zoo = new Zoo();
            var monkey = new Monkey(6, 4, "George", 9);
            zoo.AddAnimal(monkey);
            Assert.Single(zoo.GetAllAnimals());
        }

        [Fact]
        public void Zoo_ContainsAnimalNumber_ReturnsTrue_IfExists()
        {
            IZoo zoo = new Zoo();
            var wolf = new Wolf(11, 4, "Grey");
            zoo.AddAnimal(wolf);
            Assert.True(zoo.ContainsAnimalNumber(11));
        }

        [Fact]
        public void Zoo_GetAnimalByNumber_ReturnsNull_IfNotExists()
        {
            IZoo zoo = new Zoo();
            Assert.Null(zoo.GetAnimalByNumber(999));
        }

        [Fact]
        public void Zoo_TotalFoodConsumption_ReturnsSum()
        {
            IZoo zoo = new Zoo();
            zoo.AddAnimal(new Rabbit(7, 2, "Rabbit1", 8));
            zoo.AddAnimal(new Tiger(8, 5, "Tiger1"));
            Assert.Equal(7, zoo.TotalFoodConsumption());
        }

        [Fact]
        public void Zoo_AddThing_IncreasesInventoryCount()
        {
            IZoo zoo = new Zoo();
            var table = new Table(100);
            zoo.AddThing(table);
            Assert.Contains(table, zoo.GetAllInventory());
        }

        [Fact]
        public void Zoo_ContainsInventoryNumber_ReturnsTrue_IfExists()
        {
            IZoo zoo = new Zoo();
            var computer = new Computer(101);
            zoo.AddThing(computer);
            Assert.True(zoo.ContainsInventoryNumber(101));
        }

        [Fact]
        public void Zoo_AddToContactZoo_AddsOnlySuitableAnimals()
        {
            IZoo zoo = new Zoo();
            var rabbit = new Rabbit(9, 2, "Cottontail", 7);
            var tiger = new Tiger(10, 5, "Fierce");
            zoo.AddAnimal(rabbit);
            zoo.AddAnimal(tiger);
            zoo.AddToContactZoo(rabbit);
            zoo.AddToContactZoo(tiger);
            Assert.Single(zoo.GetContactZooAnimals());
            Assert.Contains(rabbit, zoo.GetContactZooAnimals());
            Assert.DoesNotContain(tiger, zoo.GetContactZooAnimals());
        }

        [Fact]
        public void Zoo_PrintAnimalsReport_DisplaysAnimals()
        {
            IZoo zoo = new Zoo();
            var rabbit = new Rabbit(13, 2, "BunnyPrint", 8);
            zoo.AddAnimal(rabbit);

            using (var sw = new StringWriter())
            {
                var originalOut = Console.Out;
                try
                {
                    Console.SetOut(sw);
                    zoo.PrintAnimalsReport();
                }
                finally
                {
                    Console.SetOut(originalOut);
                }
                var output = sw.ToString();
                Assert.Contains("BunnyPrint", output);
                Assert.Contains("Номер: 13", output);
            }
        }

        [Fact]
        public void Zoo_PrintInventory_DisplaysInventory()
        {
            IZoo zoo = new Zoo();
            var computer = new Computer(103);
            zoo.AddThing(computer);

            using (var sw = new StringWriter())
            {
                var originalOut = Console.Out;
                try
                {
                    Console.SetOut(sw);
                    zoo.PrintInventory();
                }
                finally
                {
                    Console.SetOut(originalOut);
                }
                var output = sw.ToString();
                Assert.Contains("Компьютер", output);
                Assert.Contains("103", output);
            }
        }

        #endregion

        #region ZooManager tests

        [Fact]
        public void ZooManager_AddAnimal_DoesNotAddDuplicate()
        {
            IZoo zoo = new Zoo();
            IVetClinic vetClinic = new VetClinic();
            var manager = new ZooManager(zoo, vetClinic);

            var rabbit = new Rabbit(20, 2, "Bugs", 8);
            zoo.AddAnimal(rabbit);
            var secondRabbit = new Rabbit(20, 2, "Bugs2", 5);
            if (!zoo.ContainsAnimalNumber(secondRabbit.Number))
            {
                zoo.AddAnimal(secondRabbit);
            }
            Assert.Single(zoo.GetAllAnimals());
        }

        [Fact]
        public void ZooManager_AddInventoryItem_DuplicateNumber_NotAdded()
        {
            IZoo zoo = new Zoo();
            IVetClinic vetClinic = new VetClinic();
            var manager = new ZooManager(zoo, vetClinic);

            var computer = new Computer(201);
            zoo.AddThing(computer);
            bool exists = zoo.ContainsInventoryNumber(201);
            if (!exists)
            {
                zoo.AddThing(new Computer(201));
            }
            Assert.Single(zoo.GetAllInventory());
        }

        [Fact]
        public void ZooManager_AddAnimalToContactZoo_AnimalNotFound()
        {
            IZoo zoo = new Zoo();
            IVetClinic vetClinic = new VetClinic();
            var manager = new ZooManager(zoo, vetClinic);
            var notFoundAnimal = zoo.GetAnimalByNumber(999);
            Assert.Null(notFoundAnimal);
        }

        #endregion

        #region UserInterface tests

        [Fact]
        public void UserInterface_Run_StatisticsOutput_DisplaysStats()
        {
            IZoo zoo = new Zoo();
            zoo.AddAnimal(new Rabbit(21, 3, "StatRabbit", 8));
            zoo.AddAnimal(new Tiger(22, 6, "StatTiger"));         
            zoo.AddToContactZoo(zoo.GetAllAnimals().First(a => a is Rabbit));

            ZooManager manager = new ZooManager(zoo, new VetClinic());
            var ui = new UserInterface(manager, zoo);
            using (var sr = new StringReader("4\n0\n"))
            {
                var originalIn = Console.In;
                using (var sw = new StringWriter())
                {
                    var originalOut = Console.Out;
                    try
                    {
                        Console.SetIn(sr);
                        Console.SetOut(sw);
                        ui.Run();
                    }
                    finally
                    {
                        Console.SetIn(originalIn);
                        Console.SetOut(originalOut);
                    }
                    var output = sw.ToString();
                    Assert.Contains("Общее количество животных", output);
                    Assert.Contains("Количество животных в контактном зоопарке", output);
                    Assert.Contains("Общий расход еды", output);
                    Assert.Contains("Количество хищных", output);
                    Assert.Contains("Количество травоядных", output);
                }
            }
        }

        [Fact]
        public void UserInterface_Run_InvalidChoice_ShowsError()
        {
            IZoo zoo = new Zoo();
            ZooManager manager = new ZooManager(zoo, new VetClinic());
            var ui = new UserInterface(manager, zoo);
            using (var sr = new StringReader("invalid\n0\n"))
            {
                var originalIn = Console.In;
                using (var sw = new StringWriter())
                {
                    var originalOut = Console.Out;
                    try
                    {
                        Console.SetIn(sr);
                        Console.SetOut(sw);
                        ui.Run();
                    }
                    finally
                    {
                        Console.SetIn(originalIn);
                        Console.SetOut(originalOut);
                    }
                    var output = sw.ToString();
                    Assert.Contains("Неверный ввод, попробуйте снова", output);
                }
            }
        }

        #endregion
    }
}
